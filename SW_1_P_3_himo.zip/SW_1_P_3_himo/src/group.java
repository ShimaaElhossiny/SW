public class group {
    int userId;
    String G_name , G_decripition;

    void sharePost(int userId, int postId){}
    void joinGroup(int userId){}
    void createGroup(String G_name,String G_decripition){}
    void deleteGroup(String Gname){}

}
