public class payment {
    String payment;

    void creditCard (){}
    void paypal(){}
}
