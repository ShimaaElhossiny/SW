public class registration
{
    String name , passWord , e_mail ,country ,date_of_birth;
    void register (String P_name,String P_passWord,String P_e_mail, String P_country ,String P_date_of_birth)
    {
    }
    void createAccount (){}
    String getName(){return  name;}
    String getPassword(){return this.passWord;}
    String getE_mail(){return this.e_mail;}
    String getCountry(){return this.country;}
    String getDataOfBirth(){return  this.date_of_birth;}
    void setName(String n){n=name;}
    void setPassword(String p){p=passWord;}
    void setCountry(String c){c=country;}
    void setE_mail(String e){e=e_mail;}
    void setDataOfBirth(String d){d=date_of_birth;}

}
