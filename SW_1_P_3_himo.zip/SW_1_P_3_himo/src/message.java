public class message {
    int senderId;
    int receiverId;
    String text;

    void sendMassage(String text ,int receiverId){}
    void viewMassage(){}
}
