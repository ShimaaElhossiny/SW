public class premium {
    void payment(String paymentType){}
}
