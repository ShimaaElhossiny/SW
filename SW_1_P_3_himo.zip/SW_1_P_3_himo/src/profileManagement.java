public class profileManagement {

    void saveAccount(){}
    void Ads(){}
    void savePost(){}
    void createGroup(){}
    void deleteGroup(){}
}
