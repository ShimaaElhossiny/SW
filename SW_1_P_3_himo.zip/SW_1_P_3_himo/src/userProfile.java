public class userProfile {
    String userType;
    String searchText;
    String notiText;
    String userName;
    String passWord;

    void notification(String notiText){}
    void search (String searchText){}
    void doRequest(int userId){}
    void sendMassage(String text){}
    void follow(int userId){}
    void login(){}
    void uploadAccount(){}
    void writePost(String content ,int postId){}
    void openAccount(){}


}
