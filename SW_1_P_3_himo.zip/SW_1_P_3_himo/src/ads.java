public class ads {
    String header,headerLine,description;
    int adsCount;

    void makeAds(){};
    void saveAds(){};
}
