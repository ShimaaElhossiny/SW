public class post {
    int postId;
    String content , hashtag;

    void sharePost(int userId ,int postId){}
    void likePost(int postId){}
}
